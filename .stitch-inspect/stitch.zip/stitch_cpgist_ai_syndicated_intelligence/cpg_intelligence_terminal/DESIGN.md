---
name: CPG Intelligence Terminal
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#849495'
  outline-variant: '#3a494b'
  surface-tint: '#00dce6'
  primary: '#e0fdff'
  on-primary: '#00373a'
  primary-container: '#00f2fe'
  on-primary-container: '#006a70'
  inverse-primary: '#00696f'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#f9f5ff'
  on-tertiary: '#1000a9'
  tertiary-container: '#d8d7ff'
  on-tertiary-container: '#4a4cd7'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ff6ff'
  primary-fixed-dim: '#00dce6'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f53'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  display-xl:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: 0.005em
  metric-xl:
    fontFamily: JetBrains Mono
    fontSize: 1.875rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.03em
  metric-lg:
    fontFamily: JetBrains Mono
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.625rem
    letterSpacing: -0.02em
  metric-md:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: -0.01em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.25rem
  margin: 1rem
  margin-desktop: 1.5rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

The design system establishes an institutional-grade, mission-critical workspace tailored for CPG enterprise executives, revenue growth managers, and category analysts. It fuses the information density and precision of modern financial terminals with the fluid ergonomics and aesthetic discipline of contemporary engineering tools.

The interface projects authority, analytical precision, and frictionless speed. Every pixel reinforces confidence under high-stakes decision cycles—whether evaluating trade promotion efficiency, predicting supply chain bottlenecks, or running elastic demand simulations.

Key aesthetic characteristics:
- **Obsidian & Deep Slate Architecture**: Grounded in deep neutral values that minimize eye strain during extended analytical sessions while granting maximum luminescence to critical signals.
- **Micro-Precision & Sub-Pixel Structure**: Crisp structural dividers, sharp 1px borders, and disciplined container tiers replace heavy drop shadows.
- **Instrument-Calibrated Data Contrast**: Electric cyan and emerald indicators illuminate operational health, performance lifts, and predictive AI insights against dark backdrop tiers.
- **High-Density Utility**: Optimized spatial efficiency with micro-paddings, concise tabular typography, and persistent metadata visibility.

## Colors

The palette operates on calibrated contrast ratios compliant with WCAG AAA standards for critical data points, using luminance staging to guide immediate scanning across dense grids.

### Surface Hierarchy
- **Base Canvas (`#070A0F`)**: Deep obsidian base for the overall window context and global viewport.
- **Surface Level 1 (`#0B0F17`)**: Primary container background for persistent navigation, side rails, and top toolbars.
- **Surface Level 2 (`#121824`)**: Elevated analytical cards, grid containers, multi-tab panels, and table bodies.
- **Surface Level 3 (`#1A2234`)**: Interactive states, input backgrounds, active tab pills, and subtle popovers.
- **Borders & Dividers (`#1E293B` / rgba(255, 255, 255, 0.08))**: Sub-pixel structural gridlines ensuring clear demarcation without visual clutter.

### Semantic & Validation Spectrum
- **Electric Cyan (`#00F2FE`)**: Primary brand driver, active workbench states, AI analytical prompts, and active time-series curves.
- **Emerald Pulse (`#10B981`)**: Positive delta, volume expansion, optimal inventory state, and revenue lift indicators.
- **Amber Warning (`#F59E0B`)**: SKU volatility alerts, trade spend leakage, and threshold variance flags.
- **Rose Critical (`#F43F5E`)**: Out-of-stock threats, margin erosions, and high-severity compliance anomalies.
- **Indigo Intelligence (`#6366F1`)**: Autonomous agent interventions, machine-learning forecasts, and scenario runs.

## Typography

The typographic engine balances rapid qualitative scanning with uncompromising tabular legibility.

- **Inter** commands all narrative structures, interface navigation, and analytical summaries. Medium and Semibold weights are prioritized for structural labels to preserve sharpness on low-DPI external monitors.
- **JetBrains Mono** is deployed strictly for tabular data columns, fiscal KPIs, mathematical deltas, time indices, and prompt terminal inputs. It enforces vertical numeric alignment across multi-row matrix comparisons.
- **Micro-labels and Overlines**: Styled via `label-caps` in all-caps format with loose tracking (`0.05em`) to define metadata headers without demanding visual weight.
- **Metrics**: Formatted with tabular numbers (`font-variant-numeric: tabular-nums`) enabled by default across all numerical displays to prevent layout shifts during live streaming data feeds.

## Layout & Spacing

The layout is engineered as a compact analytical workbench maximizing viewable screen real estate.

- **Layout Structure**: 12-column fluid grid system pinned between fixed-width toolbars (left application rail: 56px collapsed / 240px expanded; contextual right-hand AI Analyst panel: 360px).
- **Density Density**: High-density rhythm built on a 4px base module. Component padding defaults to `space-sm` (8px) and `space-md` (12px) to optimize data display per square inch without visual clutter.
- **Breakpoints**:
  - **Desktop Wide (>=1440px)**: 12 columns, multi-tab split screens, full terminal AI sidecar open.
  - **Desktop Compact (1024px - 1439px)**: 12 columns, right AI panel converts to floating overlay or docked drawer.
  - **Tablet (768px - 1023px)**: 8 columns, left rail collapses to icons, analytical grids convert to horizontally swipeable cards or single-column tables.
  - **Mobile (<768px)**: 4 columns, navigation translates to bottom drawer; dense data grids present summarized cards with deep-dive drill-downs.

## Elevation & Depth

Visual depth is achieved through disciplined surface layering and 1px border contrast rather than diffuse shadows, preserving the terminal aesthetic:

- **Level 0 (App Canvas)**: Absolute `#070A0F`. No border.
- **Level 1 (Structural Navigation & Shelves)**: `#0B0F17` with a 1px border (`#1E293B`) on terminating edges.
- **Level 2 (Analytical Cards & Grid Tiles)**: `#121824` with a uniform 1px outline of `rgba(255, 255, 255, 0.07)`. In hover states, this border transitions to `rgba(0, 242, 254, 0.3)`.
- **Level 3 (Dropdowns, Workspace Switchers, Popovers)**: `#1A2234` surrounded by a dual-edge treatment: `1px solid rgba(255, 255, 255, 0.12)` accompanied by a focused, low-deflection directional shadow: `0 8px 24px -4px rgba(0, 0, 0, 0.6)`.
- **Level 4 (Modals & Command Bar)**: Centered contextual overlays with a subtle backdrop blur (`backdrop-filter: blur(12px)`) on `rgba(7, 10, 15, 0.75)` and a bounding perimeter of `1px solid rgba(0, 242, 254, 0.25)`.

## Shapes

The design system adopts a precise, restrained corner geometry (`roundedness: 1` / Soft). This reinforces an analytical, hardware-inspired character while maintaining ergonomic interaction targets.

- **Base Radii (`0.25rem` / 4px)**: Buttons, text inputs, table row highlight containers, metric badge tags, and sub-tabs.
- **Panel & Card Radii (`0.5rem` / 8px)**: Primary analytical containers, charts, KPI widgets, and modal dialogues.
- **Pill Geometry (9999px)**: Reserved strictly for real-time status indicators, categorical micro-pills, and active validation severity flags to contrast with rectangular data grids.

## Components

### Action Controls (Buttons)
- **Primary**: Solid Electric Cyan (`#00F2FE`) with pitch-black typography (`#070A0F`), font weight 600. Minimal glow on hover (`box-shadow: 0 0 12px rgba(0, 242, 254, 0.35)`).
- **Secondary**: Surface Level 3 (`#1A2234`) with 1px border (`#334155`), white typography. Active press scales down slightly (`0.99`).
- **Ghost/Icon**: Transparent background, slate icon default (`#94A3B8`), illuminating to cyan or emerald on hover.

### Analytical Badges & Severities
Micro badges built with 4px inner padding, JetBrains Mono font, and muted semi-translucent fills paired with high-contrast text:
- **Info**: Background `rgba(0, 242, 254, 0.1)`, text `#00F2FE`, border `1px solid rgba(0, 242, 254, 0.2)`.
- **Warning**: Background `rgba(245, 158, 11, 0.1)`, text `#F59E0B`, border `1px solid rgba(245, 158, 11, 0.2)`.
- **Critical**: Background `rgba(244, 63, 94, 0.1)`, text `#F43F5E`, border `1px solid rgba(244, 63, 94, 0.2)`. Includes subtle 1s interval pulse on the status dot.

### KPI Statistics Tiles
- Stacked configuration: top `label-caps` title in muted slate (`#64748B`), centered `metric-xl` value in crisp white (`#F8FAFC`), bottom row featuring delta percentage (`metric-md`) paired with a mini sparkline graph.
- Positive deltas leverage emerald (`#10B981`); negative values leverage rose (`#F43F5E`).

### Data Tables & Multi-tab Views
- **Header Cells**: 32px height, uppercase `label-caps` in `#64748B`, sticky positioning, bottom border `1px solid #1E293B`.
- **Table Rows**: 36px condensed height for high-density analysis. Alternating rows subtle tint; hover creates an instant `#1A2234` row highlight.
- **Tabs**: Segmented pill control inside a dark container (`#0B0F17`). Active tab receives background `#1E293B`, white text, and a crisp bottom indicator underline in Electric Cyan.

### Enterprise Navigation & Workspace Switcher
- **Workspace Switcher**: Top-left corner selector displaying brand logo, client tenant (e.g., "Nestlé Global / Beverage Division"), and role indicator. Click opens a searchable Command palette dropdown.
- **Global Search / Command Bar**: Centered top input with keyboard shortcut pill (`Cmd + K`), triggering omni-search for SKUs, reports, and team views.

### AI Analyst Drawer
- Grounded contextual sidecar with dedicated terminal input bar.
- Generative insights render inside card containers with a faint indigo tint (`rgba(99, 102, 241, 0.05)`) and 1px border (`rgba(99, 102, 241, 0.25)`).
- Provides actionable "Run Scenario" and "Export Model" micro-buttons inline with the output text.